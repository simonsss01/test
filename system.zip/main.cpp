#include "mainwindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv); //QApplication用来管理(QT的信号与槽，QT事件响应)整个QT工程
    MainWindow w;  //创建主窗口对象，叫做w
    w.show();      //显示主窗口

//    while(1)
//    {

//    }
    return a.exec();  //进入事件循环(不断地帮你刷新主窗口)
}
