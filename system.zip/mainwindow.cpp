﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    n=0;
    flag=0;
    //最开始密码是隐藏的
    ui->pushButton_3->setStyleSheet("border-image:url(C:/Users/Administrator/Desktop/share/pic/yc.jpg);");
}

MainWindow::~MainWindow()
{
    delete ui;
}

//登录按钮对应的槽函数
void MainWindow::on_pushButton_clicked()
{
    //获取单行输入框中输入的用户名和密码
    /*
        技巧：以我们正常的思维，能够想到的方法，QT基本都提供了
        找方法，涉及到哪个类，就去类中查找(函数名或者网上搜索)
    */
    QString name=ui->lineEdit->text();
    QString passwd=ui->lineEdit_2->text();
    //判断用户名和密码
    if(name=="gec" && passwd=="123456")
        qDebug()<<"登录成功";
    else
    {
        n++;
        if(n>=3)
        {
            //锁死输入框
            ui->lineEdit->setEnabled(false);
            ui->lineEdit_2->setEnabled(false);
        }
    }

}
//密码显示隐藏按钮对应的槽函数
void MainWindow::on_pushButton_3_clicked()
{
    flag++;
    if(flag%2==1) //奇数次,密码显示
    {
        ui->lineEdit_2->setEchoMode(QLineEdit::Normal);
        ui->pushButton_3->setStyleSheet("border-image:url(C:/Users/Administrator/Desktop/share/pic/xs.jpg);");
    }
    else //奇数次,密码隐藏
    {
        ui->lineEdit_2->setEchoMode(QLineEdit::Password);
        ui->pushButton_3->setStyleSheet("border-image:url(C:/Users/Administrator/Desktop/share/pic/yc.jpg);");
    }
}
